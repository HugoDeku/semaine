import sys

sys.path.append('./model/')
sys.path.append('./model/Boss')
sys.path.append('./model/Entite')
sys.path.append('./model/Salle')
sys.path.append('./model/Jeu')
sys.path.append('./model/Joueur')
sys.path.append('./model/setSalles')
